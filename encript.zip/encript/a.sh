#!/usr/xbin/bash
#coding
bi='\033[34;1m' #biru
i='\033[32;1m' #ijo
pur='\033[35;1m' #purple
cy='\033[36;1m' #cyan
me='\033[31;1m' #merah
pu='\033[37;1m' #putih
ku='\033[33;1m' #kuning
#mrhackpro
clear
trap ctrl_c INT
ctrl_c(){
clear
cmatrix
}
echo $cy"(+)"$me"============================"$cy"(+)"
sleep 0.1
echo $me" |"$i"         Mr_HackPro"$me"           |"
sleep 0.1
echo $me" |"$ku"      ¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯¯"$me"        |"
sleep 0.1
echo $me" |"$i"   ENCRIPT : BASH-PYTHON"$me"      |"
sleep 0.1
echo $cy"(+)"$me"============================"$cy"(+)"
sleep 0.1
echo
echo $ku"=================================="
sleep 0.1
echo $ku"==="$cy" TOOLS ENCRIPT BASH-PYTHON"$ku" ===="
sleep 0.1
echo $ku"=================================="
sleep 0.1
echo
echo $me"{×}"$cy"———————(1)—————"$me"{×}"$me"{×}"$cy"———————(2)—————"$me"{×}"$me"{×}"$cy"———————(3)—————"$me"{×}"
sleep 0.1
echo $cy" |" $i"Encript bash"$cy"    |"$cy"  |" $i"Encript bashV2"$me"  |"$cy"  |" $i"Encript python"$me"  |"
sleep 0.1
echo $me"{×}"$cy"———————————————"$me"{×}"$me"{×}"$cy"———————————————"$me"{×}"$me"{×}"$cy"———————————————"$me"{×}"
sleep 0.1
echo $me"                     {×}"$cy"———————(4)—————"$me"{×}"
sleep 0.1
echo $cy"                      |" $i" Keluar saja"$cy"    |"
sleep 0.1
echo $me"                     {×}"$cy"———————————————"$me"{×}"
sleep 0.1
echo
sleep 0.1
echo $i
read -p"[Masukan Nomor] ×> " pil
if [ $pil = "1" ]; then
clear
cd bash 
python2 encript.py
fi

if [ $pil = "2" ]; then
clear
cd enbash
sh bash.sh
fi

if [ $pil = "3" ]; then
clear
cd python
sh encript-python.sh
fi

if [ $pil = "4" ];then
clear
figlet -f pagga 'SELAMAT TINGGAL' | lolcat
sleep 5
clear
fi


