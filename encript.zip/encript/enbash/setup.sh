z="
";Fz='grad';Lz='js';Az='apt ';Oz='ash-';Gz='e';Hz='pkg ';Iz='inst';Jz='all ';Bz='upda';Kz='node';Ez='t up';Mz='npm ';Qz='scat';Pz='obfu';Cz='te &';Dz='& ap';Nz='-g b';
eval "$Az$Bz$Cz$Dz$Ez$Fz$Gz$z$Hz$Iz$Jz$Kz$Lz$z$Mz$Iz$Jz$Nz$Oz$Pz$Qz$Gz"