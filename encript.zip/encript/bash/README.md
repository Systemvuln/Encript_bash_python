# Encript-Shell-Bash
Alat Untuk Encript script shell bash

pkg install nodejs

npm install -g bash-obfuscate

git clone https://github.com/muhammadfathul/Encript-Shell-Bash

cd Encript-Shell-Bash

python2 encript.py
